﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MeshSlice;

public class RuntimeShatterExample : MonoBehaviour {

    public GameObject objectToShatter;
    public Material crossSectionMaterial;

    public List<GameObject> prevShatters = new List<GameObject>();

    public GameObject[] ShatterObject(GameObject obj, Material crossSectionMaterial = null) {
        return obj.SliceInstantiate(GetRandomPlane(obj.transform.position, obj.transform.localScale),
                                                            new TextureRegion(0.0f, 0.0f, 1.0f, 1.0f),
                                                            crossSectionMaterial);
    }

    public MeshSlice.Plane GetRandomPlane(Vector3 positionOffset, Vector3 scaleOffset) {
        Vector3 randomPosition = Random.insideUnitSphere;

        Vector3 randomDirection = Random.insideUnitSphere.normalized;

        return new MeshSlice.Plane(randomPosition, randomDirection);
    }

    public void RandomShatter() {
        if (prevShatters.Count == 0) {
            GameObject[] shatters = ShatterObject(objectToShatter, crossSectionMaterial);

            if (shatters != null && shatters.Length > 0) {
                objectToShatter.SetActive(false);

                foreach (GameObject shatteredObject in shatters) {
                    shatteredObject.AddComponent<MeshCollider>().convex = true;
                    shatteredObject.AddComponent<Rigidbody>();

                    prevShatters.Add(shatteredObject);
                }
            }

            return;
        }

        GameObject randomObject = prevShatters[Random.Range(0, prevShatters.Count - 1)];

        GameObject[] randShatter = ShatterObject(randomObject, crossSectionMaterial);

        if (randShatter != null && randShatter.Length > 0) {
            randomObject.SetActive(false);

            foreach (GameObject shatteredObject in randShatter) {
                shatteredObject.AddComponent<MeshCollider>().convex = true;
                shatteredObject.AddComponent<Rigidbody>();

                prevShatters.Add(shatteredObject);
            }
        }
    }
}
