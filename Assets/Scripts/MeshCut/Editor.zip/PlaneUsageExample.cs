﻿using UnityEngine;
using MeshSlice;

public class PlaneUsageExample : MonoBehaviour {
	
	public SlicedHull SliceObject(GameObject obj, Material crossSectionMaterial = null) {
		return obj.Slice(transform.position, transform.up, crossSectionMaterial);
	}

	#if UNITY_EDITOR
	public void OnDrawGizmos() {
		MeshSlice.Plane cuttingPlane = new MeshSlice.Plane();
		cuttingPlane.Compute(transform);
		cuttingPlane.OnDebugDraw();
	}

	#endif
}
