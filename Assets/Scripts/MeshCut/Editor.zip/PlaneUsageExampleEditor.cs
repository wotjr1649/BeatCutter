﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using MeshSlice;

[CustomEditor(typeof(PlaneUsageExample))]
public class PlaneUsageExampleEditor : Editor
{
	public GameObject source;
	public Material crossMat;
	public bool recursiveSlice;

	public override void OnInspectorGUI()
	{
		PlaneUsageExample plane = (PlaneUsageExample) target;

		source = (GameObject) EditorGUILayout.ObjectField(source, typeof(GameObject), true);

		if (source == null)
		{
			EditorGUILayout.LabelField("Add a GameObject to Slice.");

			return;
		}

		if (!source.activeInHierarchy)
		{
			EditorGUILayout.LabelField("Object is Hidden. Cannot Slice.");

			return;
		}

		if (source.GetComponent<MeshFilter>() == null)
		{
			EditorGUILayout.LabelField("GameObject must have a MeshFilter.");

			return;
		}

		crossMat = (Material) EditorGUILayout.ObjectField(crossMat, typeof(Material), true);
		recursiveSlice = (bool) EditorGUILayout.Toggle("Recursive Slice", recursiveSlice);

		if (GUILayout.Button("Cut Object"))
		{
			if (!recursiveSlice)
			{
				SlicedHull hull = plane.SliceObject(source, crossMat);

				if (hull != null)
				{
					hull.CreateLowerHull(source, crossMat);
					hull.CreateUpperHull(source, crossMat);

					source.SetActive(false);
				}
			}
			else
			{
				SliceObjectRecursive(plane, source, crossMat);

				source.SetActive(false);
			}
		}
	}

	public GameObject[] SliceObjectRecursive(PlaneUsageExample plane, GameObject obj, Material crossSectionMaterial)
	{
		SlicedHull finalHull = plane.SliceObject(obj, crossSectionMaterial);

		if (finalHull != null)
		{
			GameObject lowerParent = finalHull.CreateLowerHull(obj, crossMat);
			GameObject upperParent = finalHull.CreateUpperHull(obj, crossMat);

			if (obj.transform.childCount > 0)
			{
				foreach (Transform child in obj.transform)
				{
					if (child != null && child.gameObject != null)
					{
						if (child.childCount > 0)
						{
							GameObject[] children = SliceObjectRecursive(plane, child.gameObject, crossSectionMaterial);

							if (children != null)
							{
								if (children[0] != null && lowerParent != null)
								{
									children[0].transform.SetParent(lowerParent.transform, false);
								}

								if (children[1] != null && upperParent != null)
								{
									children[1].transform.SetParent(upperParent.transform, false);
								}
							}
						}
						else
						{
							SlicedHull hull = plane.SliceObject(child.gameObject, crossSectionMaterial);

							if (hull != null)
							{
								GameObject childLowerHull = hull.CreateLowerHull(child.gameObject, crossMat);
								GameObject childUpperHull = hull.CreateUpperHull(child.gameObject, crossMat);

								if (childLowerHull != null && lowerParent != null)
								{
									childLowerHull.transform.SetParent(lowerParent.transform, false);
								}

								if (childUpperHull != null && upperParent != null)
								{
									childUpperHull.transform.SetParent(upperParent.transform, false);
								}
							}
						}
					}
				}
			}

			return new GameObject[] {lowerParent, upperParent};
		}

		return null;
	}
}
