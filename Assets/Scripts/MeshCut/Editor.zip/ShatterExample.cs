using UnityEngine;
using System.Collections;
using MeshSlice;

public class ShatterExample : MonoBehaviour {
    
    public bool ShatterObject(GameObject obj, int iterations, Material crossSectionMaterial = null) {
        if (iterations > 0) {
            GameObject[] slices = obj.SliceInstantiate(GetRandomPlane(obj.transform.position, obj.transform.localScale),
                                                       new TextureRegion(0.0f, 0.0f, 1.0f, 1.0f),
                                                       crossSectionMaterial);

            if (slices != null) {
                for (int i = 0; i < slices.Length; i++) {
                    if (ShatterObject(slices[i], iterations - 1, crossSectionMaterial)) {
                        GameObject.DestroyImmediate(slices[i]);
                    }
                }

                return true;
            }

            return ShatterObject(obj, iterations - 1, crossSectionMaterial);
        }

        return false;
    }
    
    public MeshSlice.Plane GetRandomPlane(Vector3 positionOffset, Vector3 scaleOffset) {
        Vector3 randomPosition = Random.insideUnitSphere;

        randomPosition += positionOffset;

        Vector3 randomDirection = Random.insideUnitSphere.normalized;

        return new MeshSlice.Plane(randomPosition, randomDirection);
    }
}
